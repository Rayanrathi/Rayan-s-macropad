# MCU
MCU = cortex-m0plus
PLATFORM = CHIBIOS
BOOTLOADER = atmel-dfu

# Build options
BOOTMAGIC_ENABLE      = yes
MOUSEKEY_ENABLE       = no
EXTRAKEY_ENABLE       = yes
CONSOLE_ENABLE        = no
COMMAND_ENABLE        = no
NKRO_ENABLE           = yes

# OLED (SSD1306 via I2C)
OLED_ENABLE           = yes
OLED_DRIVER           = ssd1306

# Rotary encoder
ENCODER_ENABLE        = yes
ENCODER_MAP_ENABLE    = yes
