#include QMK_KEYBOARD_H

enum layers {
    _BASE,
    _FN
};

// ─────────────────────────────────────────
// KEYMAPS  —  SW1  SW2  SW3  SW4
// ─────────────────────────────────────────
const uint16_t PROGMEM keymaps[][MATRIX_ROWS][MATRIX_COLS] = {

    [_BASE] = LAYOUT(
        KC_1,    KC_2,    KC_3,    KC_4
        // Change to anything you want, e.g.:
        // KC_MPLY, KC_MUTE, KC_VOLU, MO(_FN)
        // LCTL(KC_C), LCTL(KC_V), LCTL(KC_Z), LCTL(KC_S)
    ),

    [_FN] = LAYOUT(
        KC_F1,   KC_F2,   KC_F3,   KC_F4
    )
};

// ─────────────────────────────────────────
// ENCODER  —  SW6 rotary
// ─────────────────────────────────────────
#ifdef ENCODER_MAP_ENABLE
const uint16_t PROGMEM encoder_map[][NUM_ENCODERS][NUM_DIRECTIONS] = {
    [_BASE] = { ENCODER_CCW_CW(KC_VOLD, KC_VOLU) },
    [_FN]   = { ENCODER_CCW_CW(KC_MPRV, KC_MNXT) }
};
#endif

// ─────────────────────────────────────────
// OLED  —  0.91" SSD1306
// ─────────────────────────────────────────
#ifdef OLED_ENABLE

oled_rotation_t oled_init_user(oled_rotation_t rotation) {
    return OLED_ROTATION_0;
}

bool oled_task_user(void) {
    oled_write_P(PSTR(" RAYAN MACROPAD \n"), false);

    oled_write_P(PSTR("Layer: "), false);
    switch (get_highest_layer(layer_state)) {
        case _BASE: oled_write_P(PSTR("BASE\n"), false); break;
        case _FN:   oled_write_P(PSTR("FN  \n"), false); break;
        default:    oled_write_P(PSTR("??  \n"), false); break;
    }

    oled_write_P(PSTR("Knob: VOL -/+\n"), false);
    oled_write_P(PSTR("WPM: "), false);
    oled_write(get_u8_str(get_current_wpm(), ' '), false);

    return false;
}

#endif
